def separateRuns():
    print('******************')
    print( )    #blank line

def getGroceries(item1):    # uses one parameter variable
    print(item1)  # prints the contents of the item1 variable
    print('flour')
    print('sugar')
    print('butter')
    separateRuns()

getGroceries('eggs')
getGroceries('beer')
getGroceries('apples')
