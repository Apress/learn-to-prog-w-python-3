def getGroceries():
    print('milk')
    print('flour')
    print('sugar')
    print('butter')
    print( ) #blank line

# Main code starts here
getGroceries()
