# This function just prints a line of asterisks followed by a blank line
def separateRuns():
    print('******************')
    print ()     #blank line

def getGroceries():
    print('milk')
    print('flour')
    print('sugar')
    print('butter')
    separateRuns()     # call another function

# Main code starts here:
getGroceries()
getGroceries()
