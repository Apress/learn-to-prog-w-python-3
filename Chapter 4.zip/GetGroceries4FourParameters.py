def separateRuns():
    print('******************')
    print()     #blank line

def getGroceries(item1, item2, item3, item4):
    print(item1)
    print(item2)
    print(item3)
    print(item4)
    separateRuns()


# Now call the function with four arguments
getGroceries('eggs', 'soap', 'lettuce', 'cat food')
getGroceries('beer', 'milk', 'soda', 'peas')

