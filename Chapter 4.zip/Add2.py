def addTwo(startingValue):
    endingValue = startingValue + 2  
    print('The sum of', startingValue, 'and 2 is:', endingValue)

# Call the function twice with different arguments
addTwo(5)
addTwo(10)

