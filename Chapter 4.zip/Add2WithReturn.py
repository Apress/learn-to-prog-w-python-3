def addTwo(startingValue):
    endingValue = startingValue + 2
    return endingValue  #returns a result to the caller

sum1 = addTwo(5)
sum2 = addTwo(10)

print('The results of adding 2 to 5 and 2 to 10 are:', sum1, 'and', sum2)
