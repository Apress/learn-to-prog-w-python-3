# Calculate the total of numbers in a list

numbersList = [23, -10, 37, 4.5, 0, 123.4]

total = 0.0
for number in numbersList:
    total = total + number

print('The total of all numbers is:', total)
    
