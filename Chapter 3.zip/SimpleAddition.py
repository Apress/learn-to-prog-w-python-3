# Simple addition program

value1 = input('Please enter a number: ')
value1 = int(value1)
value2 = input('Please enter another number: ')
value2 = int(value2)
total = value1 + value2
print('The sum of', value1, 'and', value2, 'is', total)
