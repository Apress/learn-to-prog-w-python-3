# Greeting creator

firstName = input('Please enter your first name: ')
lastName = input('Please enter your last name: ')
fullName = firstName + ' ' + lastName

print('Hello', fullName, 'I hope you are doing well. ')
