# Iterate through a string
# This is the WRONG approach, just showing a concept!

state = 'Mississippi'
myIndex = 0
while myIndex < len(state):
    print(state[myIndex])
    myIndex = myIndex + 1

