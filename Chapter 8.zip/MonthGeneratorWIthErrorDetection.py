# Given a month number, find the three letter abbreviation for that month

months = 'JanFebMarAprMayJunJulAugSepOctNovDec'

while True:
    monthNumber = input('Enter a month number (1-12) (or Enter to quit): ')
    if monthNumber == '':
        break
    
    try:
        monthNumber = int(monthNumber)
    except:
        print('That was not an integer.')
        continue
    
    if (monthNumber < 1) or (monthNumber > 12):
        print('Please enter a number from 1 to 12')
        continue

    startIndex = (monthNumber - 1) * 3
    endIndex = startIndex + 3

    # Generate the appropriate slice
    monthAbbrev = months[startIndex :  endIndex]
    print(monthAbbrev)

print('OK bye')
