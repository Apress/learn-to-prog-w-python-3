# Type an a

while True:  # loop forever
    line = input("Type anything, type 'done' to exit: ")
    if line == 'done':
        break  # transfers control out of the loop

    print('You entered:', line)

print('Finished')

