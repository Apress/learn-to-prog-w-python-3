# Get weather data from openweathermap.org - as XML

import urllib.request
import xml.etree.ElementTree as etree

# API documentation from:  http://openweathermap.org/API

API_KEY = 'xxxxxx'  # <- replace with your API Key

def getInfo(city):
   
    urlWithParams = 'http://api.openweathermap.org/data/2.5/weather?q='\
                             + city + '&mode=xml' + '&APPID=' + API_KEY
    
    # Make the request and save the response as an XML-formatted string.
    connection = urllib.request.urlopen(urlWithParams)

    # Read the the data and convert to a string:
    responseString = connection.read().decode()

    print(responseString)

    # Turn the string into an XML document    
    tree = etree.fromstring(responseString)

    # Find the temperature node, then get the value attribute inside it
    temperatureInfo =  tree.find('temperature')
    degrees = temperatureInfo.attrib['value']
    
    return float(degrees)

# Convert from Kelvin degrees to Fahrenheit
def convertKToF(degreesK):
    degreesF = (1.8 * (degreesK - 273.)) + 32
    return degreesF


while True:
    city = input('What city would you like the temperature of? ')
    if city == '':
        break
    tempK = getInfo(city)

    tempF = convertKToF(tempK)
    print(tempF)
    print()






