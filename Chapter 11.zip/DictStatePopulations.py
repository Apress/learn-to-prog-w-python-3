# Get the population of a given state

statesDict = {
    'California':39776830, 'Texas':28704330, 'Florida':21312211, 'New York':19862512,\
    'Pennsylvania': 12823989, 'Illinois': 12768320, 'Ohio':11694664, 'Georgia': 10545138,\
    'North Carolina': 10390149, 'Michigan':9991177, 'New Jersey': 9032872, 'Virginia': 8525660}

while True:
    usersState = input('Enter a state: ')
    if usersState == '':
        break
    if usersState in statesDict:
        population = statesDict[usersState]
        print('The population of', usersState, 'is', population)

    else:
        print('Sorry, but we do not have any information about', usersState)
    print()

