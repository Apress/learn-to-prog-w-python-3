# Getting a stock quote

import urllib.request
import json

API_KEY = 'xxxxx'   # <- replace with your API key

#  Data provided for free by Alpha Vantage.  Website: alphavantage.co
#
#  typical URL:
#       https://www.alphavantage.co/query?function=BATCH_STOCK_QUOTES&symbols=AAPL&apikey=<key>

def getStockData(symbol):
    baseURL = 'https://www.alphavantage.co/query?function=BATCH_STOCK_QUOTES&symbols='
    ending = '&apikey=' + API_KEY

    fullURL = baseURL + symbol + ending
    print()
    print('Sending URL:', fullURL)

    # open the URL
    connection = urllib.request.urlopen(fullURL)

    # read and convert to a string
    responseString = connection.read().decode()

    print('Response is: ', responseString)
    responseDict = json.loads(responseString)  # convert from JSON to a Python dictionary
    print('Response as a dict is:', responseDict)

    # The dictionary has an entry with a key of Stock Quotes
    stockList = responseDict['Stock Quotes']

    # We get back one dictionary for every stock symbol
    # Since we only gave 1 stock symbol, we look at element 0
    stockDict = stockList[0]

    # Reach into the stock dict and pull out the price
    price = stockDict['2. price']

    return price


while True:
    print()
    userSymbol = input('Enter a stock symbol (or press ENTER to quit): ')
    if userSymbol == '':
        break
    thisStockPrice = getStockData(userSymbol)

    print()
    print('The current price of', userSymbol, 'is:', thisStockPrice)
    print()

print('OK bye')

    



