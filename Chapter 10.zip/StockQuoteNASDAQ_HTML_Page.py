# Example of 'screen scraping'
#
# This can break if  the layout of items in this page changes (the html may change)
#
# Sample page: ttps://www.nasdaq.com/symbol/aapl
#
# Treat the page full of html as one long string, and find the information we want from it using a slice

import urllib.request

def getQuote(symbol):
    # set the  base url
    baseURL = 'https://www.nasdaq.com/symbol/'
    # concatenate the stock symbol
    stockSpecificURL = baseURL + symbol

    #print('Attempting to open the connection ...')
    #print('URL is:', stockSpecificURL)
    connection = urllib.request.urlopen(stockSpecificURL)

    #print('Got the connection ...')
    responseString = connection.read().decode()

    # look for this string - the price comes right after this
    prefixString = '<div id="qwidget_lastsale" class="qwidget-dollar">'

    # do a littlemath to figure out the start and end index of the real price:
    prefixStringPosition = responseString.index(prefixString)
    prefixStringLength = len(prefixString)

    start = prefixStringPosition + prefixStringLength
    end = responseString.index('</div>', start)

    # extract the price using a slice, and return it
    price = responseString[start:end]
    return price


while True:
    userStock = input('Enter a stock symbol, or press ENTER to quit: ')
    if userStock == '':
        break
    price = getQuote(userStock)
    print()
    print('Price of', userStock, 'is :' + price)
    print()

print('Bye')

