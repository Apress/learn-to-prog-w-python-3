# Getting a stock quote

import urllib.request

API_KEY = 'xxxxx'  ##  <- Replace xxxxx with your API key

#  Data provided for free by Alpha Vantage.  Website: alphavantage.co
#
#  typical URL:
#       https://www.alphavantage.co/query?function=BATCH_STOCK_QUOTES&symbols=AAPL&apikey=<key>

def getStockData(symbol):
    baseURL = 'https://www.alphavantage.co/query?function=BATCH_STOCK_QUOTES&symbols='
    ending = '&apikey=' + API_KEY

    fullURL = baseURL + symbol + ending
    print()
    print('Sending URL:', fullURL)

    # open the URL
    connection = urllib.request.urlopen(fullURL)

    # read and convert bytes to a string
    responseString = connection.read().decode()

    print('Response is: ', responseString)

    # Look for a prefix in the response
    prefixString = '"2. price": "'
    
    # do a little math to figure out the start and end index of the real price:
    prefixStringPosition = responseString.index(prefixString)
    prefixStringLength = len(prefixString)

    start = prefixStringPosition + prefixStringLength
    end = responseString.index('"', start)

    # extract the price using a slice, and return it
    price = responseString[start:end]
    return price


while True:
    print()
    userSymbol = input('Enter a stock symbol (or press ENTER to quit): ')
    if userSymbol == '':
        break
    thisStockPrice = getStockData(userSymbol)

    print()
    print('The current price of', userSymbol, 'is:', thisStockPrice)
    print()

print('OK bye')

    



