import urllib.request

# API documentation from:  http://openweathermap.org/API

# Sample, try:  api.openweathermap.org/data/2.5/weather?q=Phoenix&mode=xml&APPID=xxxxx

API_KEY = 'xxxxx'  ##  <- Replace xxxxx with your API key

def getInfo(city):
   
    URL = 'http://api.openweathermap.org/data/2.5/weather?q=' + city + '&mode=xml'+ '&APPID=' + API_KEY

    print("URL request is: " + URL)
    print()
    
    # Make the request and save the response as a string.
    connection = urllib.request.urlopen(URL)
    responseString = connection.read().decode()

    print(responseString)
    print()

    prefixString = '<temperature value="'
   # do some small math to figure out the start and end index of the temperature:
    prefixStringLength = len(prefixString)
    prefixStringPos = responseString.index(prefixString)
    start = prefixStringPos + prefixStringLength
    end = responseString.index('"', start)

    # extract the temperature and return it
    degreesK = responseString[start : end]  # this is in degrees Kelvin
    degreesK = float(degreesK)
    return degreesK

# Convert from Kelvin degrees to Fahrenheit
def convertKToF(degreesK):
    degreesF = (1.8 * (degreesK - 273.)) + 32
    return degreesF

while True:
    city = input('What city would you like the temperature of? ')
    if city == '':
        break
    tempK = getInfo(city)
    # Convert from Kelvin degrees to Fahrenheit
    tempF = convertKToF(tempK)
    print(tempF)
    print()

print('Bye')




